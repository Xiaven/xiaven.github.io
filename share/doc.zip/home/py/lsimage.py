#coding=utf-8
import urllib,re
import time 
import os

repos=[
        "HD_R56_FDT1485",
        "HD_R56_FDT1529",
        "HD_R5601_China"
     ]

def getHtml(url):
    page = urllib.urlopen(url)
    html = page.read()
    return html


def updateInfo():
    html = getHtml("http://135.251.206.224:10000/repomanage/index.jsp")

    pattern = r'<tr.+</tr>'
    pts='<td (.+?)</tr>'
    pt = re.compile(pts, re.DOTALL)
    result = re.findall(pt, html)

    for repo in repos:
        pt2=r'.+'+repo
        for item in result:
            if re.findall(pt2,item):
                pt3 ='img src="images/(.+).gif'
                info = re.findall(pt3,item)
                if info[0] == "prohibit":
                    info[0]="Y"
                else:
                    info[0]="N"
                print repo," | LCOK: N", " | CI:", info[1]

def showImageInfo(repo):
    url = "http://135.251.206.224/IMAGE/"+repo+"/"
    html = getHtml(url)
    pt = '<a href="(.+)">'
    info = re.findall(pt, html)
    for aa in info:
        print aa

os.system("clear")
showImageInfo("HDR5601")










