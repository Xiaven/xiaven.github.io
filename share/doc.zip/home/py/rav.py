#!/usr/bin/python

import os
import commands    

includeList=[
    './include',
    './apps/public/libs/cs_msg',
    './apps/private/appkgs/cfgmgr_ms',
    './apps/private/appkgs/evtmgr_ms',
    './apps/private/appkgs/oflt',
    './apps/private/appkgs/wlan/wifihost_ng'
]

filetype=['c','cc','cpp','h','hh','hpp']


ss=os.getcwd()
repo=commands.getoutput('hg root').split('/')[-1]
#print ss

def gen_cscope():

    f=file('cscope.files','w+')

    if len(includeList):
        for path in includeList:	
            cmd = 'find ./'
            if len(filetype):
                cmd = cmd + ' -regex "'

                for type in filetype:
                    cmd = cmd+'.*\.'+type+'\|'

                cmd = cmd[0:-2]+'"'				

            print cmd
            cm="cd "+path+";"+cmd
            output = commands.getoutput(cm).split()
            for ox in output:
                fulpath=ss+path[1:]+ox[1:]
                relativepath=path+ox[1:]
                #print relativepath
                f.write(fulpath+'\n')

    f.close()

    os.system("cscope -bkqC -i cscope.files")
    #os.system("mv cscope* ~/.cache/tag/")

os.system("rm cscope*")    
gen_cscope()  
#output = commands.getoutput('hg root').split('/')
#mark=""
#for i in output[3:]:
#    mark=mark+i+"#"
#print mark[:-1]
#
#print repo





#status, output = commands.getstatusoutput(cm) 
#status, output = commands.getstatusoutput(cmd) 
#print status
#print output
