#coding=utf-8
import urllib,re
import time 
import os

repos=[
        "HD_R56_FDT1485",
        "HD_R56_FDT1529",
        "HD_R5601_China"
     ]

def getHtml(url):
    page = urllib.urlopen(url)
    html = page.read()
    return html


def updateInfo():
    html = getHtml("http://135.251.206.224:10000/repomanage/index.jsp")

    pattern = r'<tr.+</tr>'
    pts='<td (.+?)</tr>'
    pt = re.compile(pts, re.DOTALL)
    result = re.findall(pt, html)

    for repo in repos:
        pt2=r'.+'+repo
        for item in result:
            if re.findall(pt2,item):
                pt3 ='img src="images/(.+).gif'
                info = re.findall(pt3,item)
                if info[0] == "prohibit":
                    info[0]="Y"
                else:
                    info[0]="N"
                print repo," | LCOK: ", info[0], " | CI:", info[1]


os.system("clear")
ix=1
while True:
    if ix == 2:
        os.system("clear")
        ix = 1
    print "-"*40
    updateInfo()
    print "-"*40
    print " " 
    print " " 
    print " " 
    print time.strftime('                    Update on %H:%M:%S',time.localtime(time.time()))    
    time.sleep(60)
    ix=ix+1
