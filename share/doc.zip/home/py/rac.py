#!/usr/bin/python

import os
import commands    

includeList=[
	'./include',
    './apps/private/libs/RI',
	'./apps/private/libs/sal',
	'./apps/private/appkgs/cpi/wifi',
	'./apps/private/appkgs/cfgmgr_ms',
    './apps/private/appkgs/evtmgr_ms',
	'./apps/private/appkgs/wlan/wifihost',
	'./apps/private/appkgs/wlan/wifihost_ng',
	# './SDK_TMP/linux-3.18.21/arch//mips/include',
	# './SDK_TMP/modules/private/tc3162l2hp2h',
	 './SDK_TMP/modules/private/wifi/MT7603'
	# './SDK_TMP/modules/private/wifi/MT7612E_LinuxAP_3.0.4.0.P1_DPA'
]

filetype=['c','cc','cpp','h','hh','hpp']


ss=os.getcwd()
repo=commands.getoutput('hg root').split('/')[-1]
#print ss

def gen_cscope():

    f=file('cscope.files','w+')

    if len(includeList):
        for path in includeList:	
            cmd = 'find ./'
            if len(filetype):
                cmd = cmd + ' -regex "'

                for type in filetype:
                    cmd = cmd+'.*\.'+type+'\|'

                cmd = cmd[0:-2]+'"'

            #print cmd
            cm="cd "+path+";"+cmd
            print cm
            output = commands.getoutput(cm).split('\n')
            for ox in output:
                fulpath=ss+path[1:]+ox[1:]
                relativepath=path+ox[1:]
                #print relativepath
                f.write(fulpath+'\n')

    f.close()

    os.system("cscope -bkqC -i cscope.files")
    #os.system("mv cscope* ~/.cache/tag/")

def gen_ignore():
    
    f=file('.ignore','w+')
    
    path_db=[]
    includePath=[]
    if len(includeList):
        # for path_db
        for path in includeList:
            tempP=path.split('/')
                     
            rpath = path[::-1]
            #print rpath
            nPos = rpath.index('/')
            newPath = rpath[nPos:]
            ReqPath = newPath[::-1]

            path_db.append(ReqPath)  

        # for includePath
        for path in includeList:
            sp_path=path.split('/')
            #print len(sp_path),sp_path
            
            dirNum = len(sp_path) - 2
            basePath=''
            for dir in sp_path[0:-1]:
                basePath=basePath+dir
                includePath.append(basePath)
                basePath=basePath+'/'     
                
          

    paths=[]
    pathRecord=[]
    for path in path_db:
        if path not in pathRecord:
                paths.append(path[:-1])
                pathRecord.append(path)

    
                
                
                
   # ipaths = paths
    ipaths=[]
    for zz in paths:
        ipaths.append(zz)
        
   
   
   
   
    print 'paths',paths
    print "includePath",includePath
    print 'ipaths',ipaths
    for xx in includePath:
        if xx not in ipaths:
            ipaths.append(xx)
    
    for yy in includeList:
        ipaths.append(yy)
    #path_db = list(set(path_db))
    #print path_db 
    #print paths  
    print 'ipaths',ipaths    
    print 'paths',paths
    
    new_paths=[]
    # for paths
    for path in paths:
        sp_path=path.split('/')
        #print len(sp_path),sp_path
        
        dirNum = len(sp_path) - 2
        basePath=''
        for dir in sp_path[0:]:
            basePath=basePath+dir
            new_paths.append(basePath)
            basePath=basePath+'/'   
    


    tagetParent=[]
    for xx in new_paths:
        if xx not in tagetParent:
            tagetParent.append(xx)

    print "tagetParent",tagetParent
            
    # find ./apps/private/appkgs/  -maxdepth 1 -type d      
    for path in tagetParent:
        cm="find " + path + " -maxdepth 1 -type d"
        #print cm

        output = commands.getoutput(cm).split('\n')
        #print len(output), output   
        for ox in output[1:]:
            #print ox
            relativepath=ox[2:]

            writeFlag = 1
            for include in ipaths:
                #print include
                if include == ox:
                    print "one hit",ox
                    writeFlag = 0

            if writeFlag == 1:
                f.write(relativepath+'\n')


    f.write("cscope.files\n")
    f.write("cscope.in.out\n")
    f.write("cscope.out\n")
    f.write("cscope.po.out\n")
    f.write("release\n")
    f.close()
#a=includeList[0].split('/')
#print len(a)
#
#a=includeList[1].split('/')
#print len(a)


os.system("rm cscope*")
gen_cscope()
gen_ignore()
os.system("ctags -L cscope.files")









#output = commands.getoutput('hg root').split('/')
#mark=""
#for i in output[3:]:
#    mark=mark+i+"#"
#print mark[:-1]
#
#print repo





#status, output = commands.getstatusoutput(cm) 
#status, output = commands.getstatusoutput(cmd) 
#print status
#print output
