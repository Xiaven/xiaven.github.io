import os


os.system("touch bcd.diff");

d1="GLOBAL_MTK_SDK"
d2="../../../GLOBAL_MTK_SDK"
file = open("list.txt")

i=1
lines = file.readlines()
for line in lines:
    line = line.strip()
    cmd="diff -u "+d1+line+" "+d2+line+" >> bcd.diff"
    print i, cmd
    #os.system(cmd)
    i=i+1
